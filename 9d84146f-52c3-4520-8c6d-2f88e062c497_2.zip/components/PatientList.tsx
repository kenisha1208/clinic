
'use client';

import { useState } from 'react';

export default function PatientList({ patients, onAddNew, onDeletePatient, onEditPatient }) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedPatient, setSelectedPatient] = useState(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(null);

  const filteredPatients = patients.filter(patient =>
    patient.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    patient.disease.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleDelete = (patientId) => {
    onDeletePatient(patientId);
    setShowDeleteConfirm(null);
    setSelectedPatient(null);
  };

  const handleEdit = (patient) => {
    onEditPatient(patient);
    setSelectedPatient(null);
  };

  const PatientCard = ({ patient }) => (
    <div className="bg-white rounded-xl shadow-md hover:shadow-lg transition-all duration-200 p-6 border border-gray-100 relative group">
      <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
        <div className="flex space-x-2">
          <button
            onClick={(e) => {
              e.stopPropagation();
              handleEdit(patient);
            }}
            className="w-8 h-8 bg-blue-100 hover:bg-blue-200 rounded-full flex items-center justify-center cursor-pointer transition-colors"
            title="Edit Patient"
          >
            <i className="ri-edit-line text-blue-600 text-sm"></i>
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation();
              setShowDeleteConfirm(patient.id);
            }}
            className="w-8 h-8 bg-red-100 hover:bg-red-200 rounded-full flex items-center justify-center cursor-pointer transition-colors"
            title="Delete Patient"
          >
            <i className="ri-delete-bin-line text-red-600 text-sm"></i>
          </button>
        </div>
      </div>

      <div 
        className="cursor-pointer"
        onClick={() => setSelectedPatient(patient)}
      >
        <div className="flex items-start justify-between mb-4 pr-20">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
              <i className="ri-user-3-line text-green-600 text-xl"></i>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-800">{patient.name}</h3>
              <p className="text-sm text-gray-600">{patient.age} years • {patient.gender}</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-sm text-gray-500">Visit Date</p>
            <p className="text-sm font-medium text-gray-700">{patient.visitDate}</p>
          </div>
        </div>
        
        <div className="space-y-2">
          <div>
            <p className="text-xs font-semibold text-gray-600 uppercase tracking-wide">Condition</p>
            <p className="text-sm text-gray-800">{patient.disease}</p>
          </div>
          
          <div className="flex items-center justify-between pt-2">
            <div className="flex items-center space-x-2">
              <i className="ri-phone-line text-green-600"></i>
              <span className="text-sm text-gray-600">{patient.contact}</span>
            </div>
            <div className="flex items-center space-x-1 text-green-600">
              <span className="text-xs font-medium">View Details</span>
              <i className="ri-arrow-right-s-line"></i>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const DeleteConfirmModal = ({ patientId, patientName, onConfirm, onCancel }) => (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl max-w-md w-full p-6">
        <div className="text-center mb-6">
          <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <i className="ri-delete-bin-line text-red-600 text-2xl"></i>
          </div>
          <h3 className="text-lg font-semibold text-gray-800 mb-2">Delete Patient Record</h3>
          <p className="text-gray-600">
            Are you sure you want to delete <strong>{patientName}</strong>'s record? This action cannot be undone.
          </p>
        </div>
        <div className="flex space-x-3">
          <button
            onClick={onCancel}
            className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer whitespace-nowrap"
          >
            Cancel
          </button>
          <button
            onClick={() => onConfirm(patientId)}
            className="flex-1 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors cursor-pointer whitespace-nowrap"
          >
            Delete
          </button>
        </div>
      </div>
    </div>
  );

  const PatientModal = ({ patient, onClose }) => (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="bg-gradient-to-r from-green-600 to-green-700 px-6 py-4 flex items-center justify-between">
          <div>
            <h2 className="text-xl font-bold text-white">{patient.name}</h2>
            <p className="text-green-100">{patient.age} years • {patient.gender}</p>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={() => handleEdit(patient)}
              className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center hover:bg-white/30 transition-colors cursor-pointer"
              title="Edit Patient"
            >
              <i className="ri-edit-line text-white"></i>
            </button>
            <button
              onClick={() => setShowDeleteConfirm(patient.id)}
              className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center hover:bg-white/30 transition-colors cursor-pointer"
              title="Delete Patient"
            >
              <i className="ri-delete-bin-line text-white"></i>
            </button>
            <button
              onClick={onClose}
              className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center hover:bg-white/30 transition-colors cursor-pointer"
            >
              <i className="ri-close-line text-white"></i>
            </button>
          </div>
        </div>
        
        <div className="p-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-sm font-semibold text-gray-600 uppercase tracking-wide mb-2">Contact Information</h3>
              <div className="flex items-center space-x-2">
                <i className="ri-phone-line text-green-600"></i>
                <span className="text-gray-800">{patient.contact}</span>
              </div>
            </div>
            
            <div>
              <h3 className="text-sm font-semibold text-gray-600 uppercase tracking-wide mb-2">Visit Dates</h3>
              <div className="space-y-1">
                <div className="flex items-center space-x-2">
                  <i className="ri-calendar-line text-green-600"></i>
                  <span className="text-sm text-gray-800">Visit: {patient.visitDate}</span>
                </div>
                {patient.followupDate && (
                  <div className="flex items-center space-x-2">
                    <i className="ri-calendar-check-line text-blue-600"></i>
                    <span className="text-sm text-gray-800">Follow-up: {patient.followupDate}</span>
                  </div>
                )}
              </div>
            </div>
          </div>
          
          <div>
            <h3 className="text-sm font-semibold text-gray-600 uppercase tracking-wide mb-2">Medical Condition</h3>
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <p className="text-gray-800">{patient.disease}</p>
            </div>
          </div>
          
          <div>
            <h3 className="text-sm font-semibold text-gray-600 uppercase tracking-wide mb-2">Prescription & Treatment</h3>
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <p className="text-gray-800">{patient.prescription}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="max-w-6xl mx-auto">
      <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
        <div className="bg-gradient-to-r from-green-600 to-green-700 px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-white mb-2">Patient Records</h2>
              <p className="text-green-100">{patients.length} patients registered</p>
            </div>
            <button
              onClick={onAddNew}
              className="bg-white text-green-600 hover:bg-green-50 font-semibold px-6 py-3 rounded-lg transition-all duration-200 whitespace-nowrap cursor-pointer flex items-center space-x-2"
            >
              <i className="ri-add-line text-lg"></i>
              <span>Add New Patient</span>
            </button>
          </div>
        </div>
        
        <div className="p-8">
          <div className="mb-6">
            <div className="relative max-w-md">
              <input
                type="text"
                placeholder="Search patients by name or condition..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent text-sm"
              />
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                <i className="ri-search-line text-gray-400"></i>
              </div>
            </div>
          </div>
          
          {filteredPatients.length === 0 ? (
            <div className="text-center py-12">
              <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-user-search-line text-gray-400 text-3xl"></i>
              </div>
              <h3 className="text-lg font-medium text-gray-600 mb-2">No patients found</h3>
              <p className="text-gray-500">
                {searchTerm ? 'Try adjusting your search terms' : 'Start by adding your first patient'}
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredPatients.map(patient => (
                <PatientCard key={patient.id} patient={patient} />
              ))}
            </div>
          )}
        </div>
      </div>
      
      {selectedPatient && (
        <PatientModal
          patient={selectedPatient}
          onClose={() => setSelectedPatient(null)}
        />
      )}

      {showDeleteConfirm && (
        <DeleteConfirmModal
          patientId={showDeleteConfirm}
          patientName={patients.find(p => p.id === showDeleteConfirm)?.name || ''}
          onConfirm={handleDelete}
          onCancel={() => setShowDeleteConfirm(null)}
        />
      )}
    </div>
  );
}
