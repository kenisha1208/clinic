
'use client';

import { useState, useEffect } from 'react';

export default function PatientForm({ onSubmit, editingPatient, onCancelEdit }) {
  const [formData, setFormData] = useState({
    name: '',
    age: '',
    gender: '',
    disease: '',
    prescription: '',
    visitDate: '',
    followupDate: '',
    contact: ''
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const isEditing = !!editingPatient;

  useEffect(() => {
    if (editingPatient) {
      setFormData({
        name: editingPatient.name || '',
        age: editingPatient.age?.toString() || '',
        gender: editingPatient.gender || '',
        disease: editingPatient.disease || '',
        prescription: editingPatient.prescription || '',
        visitDate: editingPatient.visitDate || '',
        followupDate: editingPatient.followupDate || '',
        contact: editingPatient.contact || ''
      });
    } else {
      setFormData({
        name: '',
        age: '',
        gender: '',
        disease: '',
        prescription: '',
        visitDate: '',
        followupDate: '',
        contact: ''
      });
    }
  }, [editingPatient]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!formData.name || !formData.age || !formData.gender || !formData.disease) {
      alert('Please fill in all required fields');
      return;
    }

    setIsSubmitting(true);

    setTimeout(() => {
      if (isEditing) {
        onSubmit({ ...formData, id: editingPatient.id, age: parseInt(formData.age) });
      } else {
        onSubmit({ ...formData, age: parseInt(formData.age) });
      }

      if (!isEditing) {
        setFormData({
          name: '',
          age: '',
          gender: '',
          disease: '',
          prescription: '',
          visitDate: '',
          followupDate: '',
          contact: ''
        });
      }

      setIsSubmitting(false);
      setShowSuccess(true);
      setTimeout(() => setShowSuccess(false), 3000);
    }, 1000);
  };

  const handleCancel = () => {
    if (onCancelEdit) {
      onCancelEdit();
    }
    setFormData({
      name: '',
      age: '',
      gender: '',
      disease: '',
      prescription: '',
      visitDate: '',
      followupDate: '',
      contact: ''
    });
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
        <div className="bg-gradient-to-r from-green-600 to-green-700 px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-white mb-2">
                {isEditing ? 'Edit Patient Record' : 'Patient Registration'}
              </h2>
              <p className="text-green-100">
                {isEditing ? 'Update patient information' : 'Enter new patient information'}
              </p>
            </div>
            {isEditing && onCancelEdit && (
              <button
                onClick={handleCancel}
                className="bg-white/20 hover:bg-white/30 text-white font-medium px-4 py-2 rounded-lg transition-colors cursor-pointer whitespace-nowrap flex items-center space-x-2"
              >
                <i className="ri-close-line"></i>
                <span>Cancel</span>
              </button>
            )}
          </div>
        </div>

        <form id={isEditing ? "patient-edit" : "patient-registration"} onSubmit={handleSubmit} className="p-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Patient Name *
              </label>
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent text-sm"
                placeholder="Enter full name"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Age *
              </label>
              <input
                type="number"
                name="age"
                value={formData.age}
                onChange={handleChange}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent text-sm"
                placeholder="Age in years"
                min="1"
                max="150"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Gender *
              </label>
              <div className="relative">
                <select
                  name="gender"
                  value={formData.gender}
                  onChange={handleChange}
                  className="w-full px-4 py-3 pr-8 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent text-sm appearance-none cursor-pointer"
                  required
                >
                  <option value="">Select Gender</option>
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Other">Other</option>
                </select>
                <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                  <i className="ri-arrow-down-s-line text-gray-400"></i>
                </div>
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Contact Number
              </label>
              <input
                type="tel"
                name="contact"
                value={formData.contact}
                onChange={handleChange}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent text-sm"
                placeholder="+91 98765 43210"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Visit Date
              </label>
              <input
                type="date"
                name="visitDate"
                value={formData.visitDate}
                onChange={handleChange}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent text-sm cursor-pointer"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Follow-up Date
              </label>
              <input
                type="date"
                name="followupDate"
                value={formData.followupDate}
                onChange={handleChange}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent text-sm cursor-pointer"
              />
            </div>
          </div>

          <div className="mt-6">
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              Disease/Symptoms *
            </label>
            <textarea
              name="disease"
              value={formData.disease}
              onChange={handleChange}
              rows="3"
              maxLength="500"
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent text-sm resize-vertical"
              placeholder="Describe the patient's condition, symptoms, or diagnosis"
              required
            ></textarea>
            <div className="text-right text-xs text-gray-500 mt-1">
              {formData.disease.length}/500 characters
            </div>
          </div>

          <div className="mt-6">
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              Prescription/Treatment
            </label>
            <textarea
              name="prescription"
              value={formData.prescription}
              onChange={handleChange}
              rows="4"
              maxLength="500"
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent text-sm resize-vertical"
              placeholder="Enter prescribed medications, dosage, and treatment instructions"
            ></textarea>
            <div className="text-right text-xs text-gray-500 mt-1">
              {formData.prescription.length}/500 characters
            </div>
          </div>

          <div className="mt-8 flex justify-center space-x-4">
            {isEditing && onCancelEdit && (
              <button
                type="button"
                onClick={handleCancel}
                className="bg-gray-500 hover:bg-gray-600 text-white font-semibold px-8 py-3 rounded-lg transition-all duration-200 whitespace-nowrap cursor-pointer flex items-center space-x-2"
              >
                <i className="ri-close-line text-lg"></i>
                <span>Cancel</span>
              </button>
            )}
            <button
              type="submit"
              disabled={isSubmitting || formData.disease.length > 500 || formData.prescription.length > 500}
              className="bg-green-600 hover:bg-green-700 disabled:bg-gray-400 text-white font-semibold px-8 py-3 rounded-lg transition-all duration-200 whitespace-nowrap cursor-pointer flex items-center space-x-2"
            >
              {isSubmitting ? (
                <>
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  <span>{isEditing ? 'Updating...' : 'Saving Patient...'}</span>
                </>
              ) : (
                <>
                  <i className={`${isEditing ? 'ri-save-line' : 'ri-add-line'} text-lg`}></i>
                  <span>{isEditing ? 'Update Patient' : 'Add Patient Record'}</span>
                </>
              )}
            </button>
          </div>
        </form>

        {showSuccess && (
          <div className="mx-8 mb-8 p-4 bg-green-50 border border-green-200 rounded-lg">
            <div className="flex items-center space-x-2">
              <i className="ri-check-circle-line text-green-600 text-lg"></i>
              <p className="text-green-700 font-medium">
                {isEditing ? 'Patient record updated successfully!' : 'Patient record added successfully!'}
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
