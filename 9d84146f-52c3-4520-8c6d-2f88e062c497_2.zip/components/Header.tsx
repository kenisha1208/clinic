
'use client';

export default function Header() {
  return (
    <header className="bg-white shadow-sm border-b border-green-100">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-green-600 rounded-full flex items-center justify-center">
              <i className="ri-hospital-line text-white text-xl"></i>
            </div>
            <div>
              <h1 className="text-2xl font-bold text-green-700 font-['Pacifico']">
                Shree Hari Clinic
              </h1>
              <p className="text-sm text-green-600">Digital Patient Records</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="text-right">
              <p className="text-sm font-medium text-gray-700">Dr. Haresh Savaliya</p>
              <p className="text-xs text-gray-500">Chief Medical Officer</p>
            </div>
            <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
              <i className="ri-user-line text-green-600 text-lg"></i>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
