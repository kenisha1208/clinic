
'use client';

import { useState } from 'react';
import Header from '../components/Header';
import PatientForm from '../components/PatientForm';
import PatientList from '../components/PatientList';

export default function Home() {
  const [currentView, setCurrentView] = useState('form');
  const [editingPatient, setEditingPatient] = useState(null);
  const [patients, setPatients] = useState([
    {
      id: 1,
      name: 'Rajesh Kumar',
      age: 45,
      gender: 'Male',
      disease: 'Hypertension',
      prescription: 'Amlodipine 5mg daily',
      visitDate: '2024-01-15',
      followupDate: '2024-02-15',
      contact: '+91 98765 43210'
    },
    {
      id: 2,
      name: 'Priya Sharma',
      age: 32,
      gender: 'Female',
      disease: 'Diabetes Type 2',
      prescription: 'Metformin 500mg twice daily',
      visitDate: '2024-01-14',
      followupDate: '2024-02-14',
      contact: '+91 87654 32109'
    },
    {
      id: 3,
      name: 'Amit Singh',
      age: 28,
      gender: 'Male',
      disease: 'Common Cold',
      prescription: 'Paracetamol 500mg as needed',
      visitDate: '2024-01-13',
      followupDate: '2024-01-20',
      contact: '+91 76543 21098'
    }
  ]);

  const addOrUpdatePatient = (patientData) => {
    if (editingPatient) {
      setPatients(patients.map(patient => 
        patient.id === editingPatient.id ? { ...patientData, id: editingPatient.id } : patient
      ));
      setEditingPatient(null);
    } else {
      const newPatient = {
        ...patientData,
        id: Math.max(...patients.map(p => p.id), 0) + 1
      };
      setPatients([...patients, newPatient]);
    }
    setCurrentView('list');
  };

  const deletePatient = (patientId) => {
    setPatients(patients.filter(patient => patient.id !== patientId));
  };

  const editPatient = (patient) => {
    setEditingPatient(patient);
    setCurrentView('form');
  };

  const cancelEdit = () => {
    setEditingPatient(null);
    setCurrentView('list');
  };

  const addNewPatient = () => {
    setEditingPatient(null);
    setCurrentView('form');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-green-700 mb-2 font-['Pacifico']">
            Shree Hari Clinic
          </h1>
          <p className="text-xl text-green-600 font-semibold">
            Patient Management System
          </p>
        </div>

        <div className="flex justify-center mb-8">
          <div className="bg-white rounded-full p-1 shadow-md">
            <button
              onClick={addNewPatient}
              className={`px-6 py-2 rounded-full font-medium transition-all whitespace-nowrap cursor-pointer ${
                currentView === 'form' && !editingPatient
                  ? 'bg-green-600 text-white shadow-md'
                  : 'text-green-600 hover:bg-green-50'
              }`}
            >
              Add New Patient
            </button>
            <button
              onClick={() => {
                setEditingPatient(null);
                setCurrentView('list');
              }}
              className={`px-6 py-2 rounded-full font-medium transition-all whitespace-nowrap cursor-pointer ${
                currentView === 'list'
                  ? 'bg-green-600 text-white shadow-md'
                  : 'text-green-600 hover:bg-green-50'
              }`}
            >
              View All Patients
            </button>
          </div>
        </div>

        {currentView === 'form' ? (
          <PatientForm 
            onSubmit={addOrUpdatePatient} 
            editingPatient={editingPatient}
            onCancelEdit={cancelEdit}
          />
        ) : (
          <PatientList 
            patients={patients} 
            onAddNew={addNewPatient}
            onDeletePatient={deletePatient}
            onEditPatient={editPatient}
          />
        )}
      </main>
    </div>
  );
}
